/*
 * timer1.h
 *
 * Created: 10/10/2023 6:29:00 pm
 *  Author: Jenny W
 */ 


#ifndef TIMER1_H_
#define TIMER1_H_

void timer1_init();


#endif /* TIMER1_H_ */