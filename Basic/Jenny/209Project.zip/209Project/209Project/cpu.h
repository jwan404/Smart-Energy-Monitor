/*
 * cpu.h
 *
 * Created: 10/10/2023 4:18:10 pm
 *  Author: Jenny W
 */ 


#ifndef CPU_H_
#define CPU_H_
#define F_CPU 2000000UL 
#include <stdint.h>
#define NUM_SAMPLES 50



#endif /* CPU_H_ */