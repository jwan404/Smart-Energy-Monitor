/*
 * timer0.h
 *
 * Created: 10/10/2023 6:08:09 pm
 *  Author: Jenny W
 */ 


#ifndef TIMER0_H_
#define TIMER0_H_

void timer0_init();

#endif /* TIMER0_H_ */